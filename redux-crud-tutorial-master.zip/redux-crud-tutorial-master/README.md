### Simple React Redux CRUD app for my tutorial on Dev.to
